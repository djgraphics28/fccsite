<div>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Birth Date</th>
                <th>Age</th>
                <th>Contact Number</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($row->first_name); ?> <?php echo e($row->middle_name); ?> <?php echo e($row->last_name); ?> <?php echo e($row->ext_name); ?></td>
                    <td><?php echo e($row->gender); ?></td>
                    <td><?php echo e($row->birth_date); ?></td>
                    <td></td>
                    <td><?php echo e($row->contact_number); ?></td>
                    <td><?php echo e($row->address); ?></td>
                    <td>
                        <button class="btn btn-warning">Edit</button>
                        <button class="btn btn-danger">Remove</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\fccsite\resources\views/livewire/members-table.blade.php ENDPATH**/ ?>