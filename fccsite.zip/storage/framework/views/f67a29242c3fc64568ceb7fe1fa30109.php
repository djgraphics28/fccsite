<div>
    <div class="p-4">
        <div class="text-center">
            <img src="<?php echo e(asset('FCCPI.png')); ?>" alt="FCCPI Logo" width="50px" class="mb-2">
            <h1 class="h4 text-dark mb-4">Membership Form</h1>
        </div>
        <?php $__errorArgs = ['nameCombination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <form class="user" wire:submit.prevent="store">
            <div class="form-group row">
                <div class="col-sm-6 mb-3 mb-sm-0">
                    <label for="firstName">First Name</label>
                    <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="firstName" wire:model="firstName">

                    <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-6">
                    <label for="middleName">Middle Name (optional)</label>
                    <input type="text" class="form-control form-control-lg" id="middleName" wire:model="middleName">
                </div>
            </div>

            <div class="form-group row">
                <div class="col-sm-6  mb-3 mb-sm-0">
                    <label for="lastName">Last Name</label>
                    <input type="text" class="form-control form-control-lg <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="lastName" wire:model="lastName">
                    <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-sm-6">
                    <label for="extName">Extension Name (ex. JR,SR.) (optional)</label>
                    <input type="text" class="form-control form-control-lg" id="extName" wire:model="extName">
                </div>
            </div>
            <div class="form-group">
                <label for="gender">Gender</label>
               <select class="form-control form-control-lg <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gender" wire:model="gender">
                    <option value="">Select option</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
               </select>
               <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="birthDate">Birth Date</label>
                <input type="date" class="form-control form-control-lg <?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="birthDate" wire:model="birthDate">
                <?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="contactNumber">Contact Number</label>
                <input type="number" class="form-control form-control-lg" id="contactNumber" wire:model="contactNumber">
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea class="form-control" cols="30" rows="3" wire:model="address"></textarea>
            </div>
            <div class="form-group">
                <label for="email">EmailAddress</label>
                <input type="email" class="form-control form-control-lg" id="email" placeholder="example@gmail.com">
            </div>
            <div class="form-group">
                <label for="dateBaptized">If already baptized, When? (optional)</label>
                <input type="date" class="form-control form-control-lg" id="dateBaptized" wire:model="dateBaptized">
            </div>

            <button type="submit" class="btn btn-primary btn-user btn-block mt-4">
                SUBMIT REGISTRATION
            </button>
            <hr>
            
        </form>
        
    </div>
</div>
<?php /**PATH C:\laragon\www\fccsite\resources\views/livewire/registration-component.blade.php ENDPATH**/ ?>