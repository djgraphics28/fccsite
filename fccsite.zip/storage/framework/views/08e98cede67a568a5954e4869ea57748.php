<?php $__env->startSection('content'); ?>
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                
                <div class="col-lg-12">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registration-component')->html();
} elseif ($_instance->childHasBeenRendered('TK4RP9V')) {
    $componentId = $_instance->getRenderedChildComponentId('TK4RP9V');
    $componentTag = $_instance->getRenderedChildComponentTagName('TK4RP9V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TK4RP9V');
} else {
    $response = \Livewire\Livewire::mount('registration-component');
    $html = $response->html();
    $_instance->logRenderedChild('TK4RP9V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.registration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fccsite\resources\views/registration.blade.php ENDPATH**/ ?>