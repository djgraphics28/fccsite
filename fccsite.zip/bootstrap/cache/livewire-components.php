<?php return array (
  'members-table' => 'App\\Http\\Livewire\\MembersTable',
  'registration-component' => 'App\\Http\\Livewire\\RegistrationComponent',
);